﻿using System;
using System.IO;

namespace MazeManiac
{
    class Program
    {
        static void Main(string[] args)
        {
            Player jatekos = new Player();
            MapHandler map1 = new MapHandler("elso.txt", jatekos);
            MapHandler map2 = new MapHandler("masodik.txt", jatekos);           

            bool gameIsRunning = true;          
            
            map1.showMap();
            while (gameIsRunning) {
                if (map1.CurrentMap==1)
                {
                    char command = Console.ReadKey(true).KeyChar;

                    Console.Clear();

                    switch (command)
                    {
                        case 'w': map1.up(); break;
                        case 's': map1.down(); break;
                        case 'a': map1.left(); break;
                        case 'd': map1.right(); break;
                        case 'f': Console.WriteLine(map1.whereAmI()[0] + "|" + map1.whereAmI()[1]); break;
                        default: Console.WriteLine("Nincs ilyen parancs!"); break;
                    }
                    if (map1.GameIsOver)
                    {
                        map1.showAndClearMessage();
                    }
                    else
                    {
                        map1.showMap();
                        map1.showAndClearMessage();
                    }
                }
                else if (map1.CurrentMap==2)
                {
                    char command = Console.ReadKey(true).KeyChar;

                    Console.Clear();

                    switch (command)
                    {
                        case 'w': map2.up(); break;
                        case 's': map2.down(); break;
                        case 'a': map2.left(); break;
                        case 'd': map2.right(); break;
                        case 'f': Console.WriteLine(map2.whereAmI()[0] + "|" + map2.whereAmI()[1]); break;
                        default: Console.WriteLine("Nincs ilyen parancs!"); break;
                    }
                    if (map2.GameIsOver)
                    {
                        map2.showAndClearMessage();
                        gameIsRunning = false;
                    }
                    else
                    {
                        map2.showMap();
                        map2.showAndClearMessage();
                    }
                }                                                                      
            }           

            Console.ReadKey();
        }
    }
}
